#opdracht 1a
studiejaar = 1357

jouwklass = int(input("hoeveel leerling bij jouw in de klass: "))
sum = studiejaar * jouwklass
print ("het is zoveel:", sum)

#opdracht 1b
print((3.40 + 2.45 + 1.95) / 109 * 9)

#opdracht 2
woord_1 = input("Wat is voor weer?: ")
stad_1 = input("Welke stad?: ")
naam_1 = input("Welke naam?: ")
woord_3 = input("Wat zoek je vaak?: ")
woord_4 = input("Welke soort van vrouw heb je ontmoet?: ")
woord_5 = input("Wat heeft zij verkocht?: ")
woord_6 = input("Welke plaats kwam je?: ")
woord_zin_7 = input("Wat doen een groep van mensen?: ")


verhaal = print("Het was een " + woord_1 + " dag in " + stad_1 + "." + naam_1 + " liep door de straten, op zoek naar een " + woord_3 + ". Plotseling" + naam_1 + " je een" + woord_4 + " vrouw sie een " + woord_5 + " verkocht." + naam_1 + " besloot om het te kopen en liep verder." + "Toen " + naam_1 + "bij een " + woord_6 + " kwam, zag zij een groep mensen die " + woord_zin_7 + "." + naam_1 + " besloot om mee te doen en had de tijd van haar leven")