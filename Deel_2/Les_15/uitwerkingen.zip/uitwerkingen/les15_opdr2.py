# Opdracht 2:
# Schrijf een functie met twee parameters (integers).
# De functie retourneert de vermenigvuldiging van de twee parameters.

def keerfunctie(getal1 , getal2):
    keer = getal1 * getal2
    return keer


getal1 = 10
getal2 = 5
resultaat = keerfunctie(getal1, getal2)
print(f"De som van {getal1} en {getal2} is {resultaat}")
