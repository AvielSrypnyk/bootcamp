# Opdracht 4:
# Verslavend: de gebruikers vinden je game zo leuk dat ze er niet mee kunnen stoppen.
# Pas je game daarom als volgt aan: 
# - goed geraden? Vraag of de gebruiker nog een ronde wil spelen.
# - aan het einde print je het aantal gespeelde ronden en het aantal keer dat de gebruiker fout heeft geraden.
import random

a = random.randint(1, 5)
GoodStreak = 0 
aantaal_keer = 0
aantaal_fouten = 0

while GoodStreak < 3 and aantaal_keer + 1:
    vraag = int(input("Voer je nummer van 1 - 5 in: "))
    if vraag == a:
        print("Je hebt het juiste getal geraden! Het is", a)
        GoodStreak += 1
    else:
        print("Je hebt het getal niet goed geraden. Probeer opnieuw.")
        GoodStreak = 0
        aantaal_fouten += 1